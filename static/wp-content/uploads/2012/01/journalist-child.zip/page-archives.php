<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage jornalist
 * @since jornalist 0.9
 */
$numpostsarray	= wp_count_posts('post');
$numposts		= $numpostsarray->publish;

$numcommsarray	= wp_count_comments();
$numcomms		= $numcommsarray->approved;

$numcats = count(get_all_category_ids());

get_header(); ?>

<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="post hentry<?php if (function_exists('sticky_class')) { sticky_class(); } ?>">
<h2 id="post-<?php the_ID(); ?>" class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
<p class="comments"><a href="<?php comments_link(); ?>"><?php comments_number('leave a comment','one comment','% comments'); ?></a></p>

<div class="main entry-content group">

					<?php get_template_part( 'content', 'link' ); ?>

					<div class="entry-content">

						<p class="archivetext"><?php printf(__('This is the frontpage of the %1$s archives. Currently the archives are spanning %2$s posts and %3$s comments, contained within the meager confines of %4$s categories. Through here, you will be able to move down into the archives by way of time or category. If you are looking for something specific, perhaps you should try the search on the sidebar.','k2_domain'), get_bloginfo('name'), $numposts, $numcomms, $numcats); ?></p>

						<h3><?php _e('Tag Cloud'); ?></h3>
						<div id="tag-cloud">
						<?php wp_tag_cloud('number=0'); ?>
						</div>

						<h3><?php _e('Browse by Month'); ?></h3>
						<ul class="archive-list">
							<?php wp_get_archives('show_post_count=1'); ?>
						</ul>

						<h3><?php _e('Browse by Category'); ?></h3>
						<ul class="archive-list">
							<?php wp_list_cats('hierarchical=0&optioncount=1'); ?>
						</ul>

						<br class="clear" />

					</div><!-- .entry-content -->

	<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
</div>

<div class="meta group">
<div class="signature">
    <p class="author vcard">Written by <span class="fn"><?php the_author() ?></span> <span class="edit"><?php edit_post_link('Edit'); ?></span></p>
    <p><abbr class="updated" title="<?php the_time('Y-m-d\TH:i:s')?>"><?php the_time('F jS, Y'); ?> <?php _e("at"); ?> <?php the_time('g:i a'); ?></abbr></p>
</div>
<div class="tags">
    <?php if ( the_tags('<p>Tagged with ', ', ', '</p>') ) ?>
</div>
</div>
</div><!-- END .hentry -->

<?php // if ( comments_open() ) comments_template(); ?>

<?php endwhile; else: ?>
<div class="warning">
	<p>Sorry, but you are looking for something that isn't here.</p>
</div>
<?php endif; ?>

</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>

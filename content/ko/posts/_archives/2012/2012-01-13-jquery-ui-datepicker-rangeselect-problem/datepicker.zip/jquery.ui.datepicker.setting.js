/*!
 * jQuery UI datepicker setting
 * 2012-01-13 김용균
 */
$(function(){
	$.datepicker.regional['ko'] = {
		closeText: '닫기',
		prevText: '이전달',
		nextText: '다음달',
		currentText: '오늘',
		monthNames: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
		monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
		dayNames: ['일','월','화','수','목','금','토'],
		dayNamesShort: ['일','월','화','수','목','금','토'],
		dayNamesMin: ['일','월','화','수','목','금','토'],
		weekHeader: 'Wk',
		dateFormat: 'yy-mm-dd',
		todayHightlight : false, // 오늘 날짜 표시 안함 true하면 표시
		firstDay: 0,
		isRTL: false,
		showMonthAfterYear: true,
		minDate : '-0d',	/*최소선택일수*/
		/*numberOfMonths: 2,*/	/*표시되는 개월수*/
		showButtonPanel: false,
		yearSuffix: '년',
        showOn: 'button',
		buttonImage: './images/calendar.gif',
		buttonImageOnly: true,
        buttonText: "달력",
		onSelect: function(dateText, inst) {
			if(inst.settings.target !== undefined){
				if(inst.settings.target.length == 1){
					//하나일 때
					$(inst.settings.target[0]).val(dateText);
				}else{
					//두개일 때
					target1 = inst.settings.target[0];
					target2 = inst.settings.target[1];
					tempDate = dateText.replace(/-/g,'');
					if( inst.tempDate > tempDate ){
						inst.dateType = 1;
					}
					inst.tempDate = tempDate;
					if(!inst.dateType){ inst.dateType = 1; }
					if(inst.dateType == 1){
						inst.beforeDay		= null;
						inst.beforeMonth	= null;
						inst.beforeYear		= null;

						inst.afterDay		= inst.selectedDay;
						inst.afterMonth		= inst.selectedMonth;
						inst.afterYear		= inst.selectedYear;

						inst.dateType = 2;
						$(target1).val(dateText);
						$(target2).val('');
					}else if(inst.dateType == 2){
						inst.beforeDay		= inst.afterDay;
						inst.beforeMonth	= inst.afterMonth;
						inst.beforeYear		= inst.afterYear;

						inst.afterDay		= null;
						inst.afterMonth		= null;
						inst.afterYear		= null;

						inst.dateType = 1;
						$(target2).val(dateText);
					}
				}
			}
		}
	};
	$.datepicker.setDefaults($.datepicker.regional['ko']);
});
